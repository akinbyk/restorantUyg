﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace project
{
	class baglanti
	{
		public string Adres = System.IO.File.ReadAllText("@C:\\Test.txt");
	}
}
