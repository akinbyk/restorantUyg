﻿namespace project
{
	partial class Home
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
			System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
			System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
			System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.panel1 = new System.Windows.Forms.Panel();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.listBox5 = new System.Windows.Forms.ListBox();
			this.listBox4 = new System.Windows.Forms.ListBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.button8 = new System.Windows.Forms.Button();
			this.label9 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.button4 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.barkodlu_kaydet = new System.Windows.Forms.Button();
			this.textBox9 = new System.Windows.Forms.TextBox();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.textBox7 = new System.Windows.Forms.TextBox();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.listBox3 = new System.Windows.Forms.ListBox();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.textBox14 = new System.Windows.Forms.TextBox();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.label4 = new System.Windows.Forms.Label();
			this.button7 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.barkodsuz_kaydet = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.barkodsuz_urun_grubu_guncelle = new System.Windows.Forms.Button();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.panel2 = new System.Windows.Forms.Panel();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.dateTimePicker12 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker11 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker10 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker9 = new System.Windows.Forms.DateTimePicker();
			this.label31 = new System.Windows.Forms.Label();
			this.label30 = new System.Windows.Forms.Label();
			this.dateTimePicker8 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker7 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker6 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker5 = new System.Windows.Forms.DateTimePicker();
			this.button6 = new System.Windows.Forms.Button();
			this.label18 = new System.Windows.Forms.Label();
			this.label17 = new System.Windows.Forms.Label();
			this.label16 = new System.Windows.Forms.Label();
			this.label15 = new System.Windows.Forms.Label();
			this.label14 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.textBox13 = new System.Windows.Forms.TextBox();
			this.textBox12 = new System.Windows.Forms.TextBox();
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.dataGridView5 = new System.Windows.Forms.DataGridView();
			this.label12 = new System.Windows.Forms.Label();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.label11 = new System.Windows.Forms.Label();
			this.textBox10 = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.textBox11 = new System.Windows.Forms.TextBox();
			this.button3 = new System.Windows.Forms.Button();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
			this.button1 = new System.Windows.Forms.Button();
			this.groupBox9 = new System.Windows.Forms.GroupBox();
			this.button12 = new System.Windows.Forms.Button();
			this.comboBox6 = new System.Windows.Forms.ComboBox();
			this.comboBox7 = new System.Windows.Forms.ComboBox();
			this.label27 = new System.Windows.Forms.Label();
			this.label28 = new System.Windows.Forms.Label();
			this.groupBox8 = new System.Windows.Forms.GroupBox();
			this.button11 = new System.Windows.Forms.Button();
			this.comboBox4 = new System.Windows.Forms.ComboBox();
			this.comboBox5 = new System.Windows.Forms.ComboBox();
			this.label25 = new System.Windows.Forms.Label();
			this.label26 = new System.Windows.Forms.Label();
			this.groupBox7 = new System.Windows.Forms.GroupBox();
			this.button10 = new System.Windows.Forms.Button();
			this.comboBox3 = new System.Windows.Forms.ComboBox();
			this.groupBox6 = new System.Windows.Forms.GroupBox();
			this.button9 = new System.Windows.Forms.Button();
			this.comboBox2 = new System.Windows.Forms.ComboBox();
			this.listBox1 = new System.Windows.Forms.ListBox();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
			this.label21 = new System.Windows.Forms.Label();
			this.label20 = new System.Windows.Forms.Label();
			this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.openFileDialog2 = new System.Windows.Forms.OpenFileDialog();
			this.denemeDataSet1 = new project.denemeDataSet1();
			this.denemeDataSet1BindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.tabPage2.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
			this.tabPage3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
			this.groupBox9.SuspendLayout();
			this.groupBox8.SuspendLayout();
			this.groupBox7.SuspendLayout();
			this.groupBox6.SuspendLayout();
			this.groupBox5.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.denemeDataSet1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.denemeDataSet1BindingSource)).BeginInit();
			this.SuspendLayout();
			// 
			// tabControl1
			// 
			this.tabControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.ItemSize = new System.Drawing.Size(110, 100);
			this.tabControl1.Location = new System.Drawing.Point(0, 0);
			this.tabControl1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(1680, 996);
			this.tabControl1.SizeMode = System.Windows.Forms.TabSizeMode.Fixed;
			this.tabControl1.TabIndex = 0;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.panel1);
			this.tabPage1.Controls.Add(this.groupBox2);
			this.tabPage1.Controls.Add(this.groupBox1);
			this.tabPage1.Location = new System.Drawing.Point(4, 104);
			this.tabPage1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tabPage1.Size = new System.Drawing.Size(1672, 888);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Urun Ekle";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// panel1
			// 
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(1614, 73);
			this.panel1.TabIndex = 4;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.listBox5);
			this.groupBox2.Controls.Add(this.listBox4);
			this.groupBox2.Controls.Add(this.pictureBox2);
			this.groupBox2.Controls.Add(this.button8);
			this.groupBox2.Controls.Add(this.label9);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this.label6);
			this.groupBox2.Controls.Add(this.label5);
			this.groupBox2.Controls.Add(this.button4);
			this.groupBox2.Controls.Add(this.button5);
			this.groupBox2.Controls.Add(this.barkodlu_kaydet);
			this.groupBox2.Controls.Add(this.textBox9);
			this.groupBox2.Controls.Add(this.textBox8);
			this.groupBox2.Controls.Add(this.textBox7);
			this.groupBox2.Controls.Add(this.textBox6);
			this.groupBox2.Controls.Add(this.textBox5);
			this.groupBox2.Location = new System.Drawing.Point(887, 100);
			this.groupBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox2.Size = new System.Drawing.Size(753, 651);
			this.groupBox2.TabIndex = 3;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Barkodlu";
			// 
			// listBox5
			// 
			this.listBox5.FormattingEnabled = true;
			this.listBox5.ItemHeight = 16;
			this.listBox5.Location = new System.Drawing.Point(292, 152);
			this.listBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.listBox5.Name = "listBox5";
			this.listBox5.Size = new System.Drawing.Size(192, 356);
			this.listBox5.TabIndex = 29;
			this.listBox5.SelectedIndexChanged += new System.EventHandler(this.listBox5_SelectedIndexChanged);
			// 
			// listBox4
			// 
			this.listBox4.FormattingEnabled = true;
			this.listBox4.ItemHeight = 16;
			this.listBox4.Location = new System.Drawing.Point(35, 152);
			this.listBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.listBox4.Name = "listBox4";
			this.listBox4.Size = new System.Drawing.Size(192, 356);
			this.listBox4.TabIndex = 28;
			this.listBox4.SelectedIndexChanged += new System.EventHandler(this.listBox4_SelectedIndexChanged);
			// 
			// pictureBox2
			// 
			this.pictureBox2.Location = new System.Drawing.Point(594, 19);
			this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(133, 133);
			this.pictureBox2.TabIndex = 26;
			this.pictureBox2.TabStop = false;
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(557, 23);
			this.button8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(32, 26);
			this.button8.TabIndex = 25;
			this.button8.Text = "***";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(289, 94);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(60, 17);
			this.label9.TabIndex = 23;
			this.label9.Text = "ürün adı";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(31, 94);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(78, 17);
			this.label8.TabIndex = 22;
			this.label8.Text = "ürün grubu";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(484, 28);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(57, 17);
			this.label7.TabIndex = 21;
			this.label7.Text = "fotograf";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(289, 20);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(52, 17);
			this.label6.TabIndex = 20;
			this.label6.Text = "barkod";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(34, 23);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(34, 17);
			this.label5.TabIndex = 19;
			this.label5.Text = "fiyat";
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(37, 548);
			this.button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(80, 72);
			this.button4.TabIndex = 12;
			this.button4.Text = "güncelle";
			this.button4.UseVisualStyleBackColor = true;
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(292, 542);
			this.button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(80, 72);
			this.button5.TabIndex = 13;
			this.button5.Text = "güncelle";
			this.button5.UseVisualStyleBackColor = true;
			// 
			// barkodlu_kaydet
			// 
			this.barkodlu_kaydet.Location = new System.Drawing.Point(628, 542);
			this.barkodlu_kaydet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.barkodlu_kaydet.Name = "barkodlu_kaydet";
			this.barkodlu_kaydet.Size = new System.Drawing.Size(80, 72);
			this.barkodlu_kaydet.TabIndex = 14;
			this.barkodlu_kaydet.Text = "kaydet";
			this.barkodlu_kaydet.UseVisualStyleBackColor = true;
			this.barkodlu_kaydet.Click += new System.EventHandler(this.barkodlu_kaydet_Click);
			// 
			// textBox9
			// 
			this.textBox9.Location = new System.Drawing.Point(292, 113);
			this.textBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox9.Name = "textBox9";
			this.textBox9.Size = new System.Drawing.Size(101, 22);
			this.textBox9.TabIndex = 5;
			// 
			// textBox8
			// 
			this.textBox8.Location = new System.Drawing.Point(35, 113);
			this.textBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox8.Name = "textBox8";
			this.textBox8.Size = new System.Drawing.Size(101, 22);
			this.textBox8.TabIndex = 4;
			// 
			// textBox7
			// 
			this.textBox7.Location = new System.Drawing.Point(488, 54);
			this.textBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox7.Name = "textBox7";
			this.textBox7.Size = new System.Drawing.Size(101, 22);
			this.textBox7.TabIndex = 3;
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(292, 42);
			this.textBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(101, 22);
			this.textBox6.TabIndex = 2;
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(35, 43);
			this.textBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(101, 22);
			this.textBox5.TabIndex = 1;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.listBox3);
			this.groupBox1.Controls.Add(this.listBox2);
			this.groupBox1.Controls.Add(this.textBox14);
			this.groupBox1.Controls.Add(this.pictureBox1);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.button7);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.barkodsuz_kaydet);
			this.groupBox1.Controls.Add(this.button2);
			this.groupBox1.Controls.Add(this.barkodsuz_urun_grubu_guncelle);
			this.groupBox1.Controls.Add(this.textBox4);
			this.groupBox1.Controls.Add(this.textBox3);
			this.groupBox1.Controls.Add(this.textBox2);
			this.groupBox1.Controls.Add(this.textBox1);
			this.groupBox1.Location = new System.Drawing.Point(32, 90);
			this.groupBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox1.Size = new System.Drawing.Size(733, 651);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Barkodsuz";
			// 
			// listBox3
			// 
			this.listBox3.FormattingEnabled = true;
			this.listBox3.ItemHeight = 16;
			this.listBox3.Location = new System.Drawing.Point(306, 152);
			this.listBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.listBox3.Name = "listBox3";
			this.listBox3.Size = new System.Drawing.Size(192, 372);
			this.listBox3.TabIndex = 28;
			this.listBox3.SelectedIndexChanged += new System.EventHandler(this.listBox3_SelectedIndexChanged);
			// 
			// listBox2
			// 
			this.listBox2.FormattingEnabled = true;
			this.listBox2.ItemHeight = 16;
			this.listBox2.Location = new System.Drawing.Point(28, 152);
			this.listBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(192, 372);
			this.listBox2.TabIndex = 27;
			this.listBox2.SelectedIndexChanged += new System.EventHandler(this.listBox2_SelectedIndexChanged);
			// 
			// textBox14
			// 
			this.textBox14.Enabled = false;
			this.textBox14.Location = new System.Drawing.Point(573, 191);
			this.textBox14.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox14.Name = "textBox14";
			this.textBox14.Size = new System.Drawing.Size(99, 22);
			this.textBox14.TabIndex = 26;
			this.textBox14.Visible = false;
			// 
			// pictureBox1
			// 
			this.pictureBox1.Location = new System.Drawing.Point(573, 19);
			this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(133, 133);
			this.pictureBox1.TabIndex = 25;
			this.pictureBox1.TabStop = false;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(302, 94);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(60, 17);
			this.label4.TabIndex = 18;
			this.label4.Text = "ürün adı";
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(532, 21);
			this.button7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(31, 26);
			this.button7.TabIndex = 24;
			this.button7.Text = "***";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(25, 94);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(78, 17);
			this.label3.TabIndex = 17;
			this.label3.Text = "ürün grubu";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(461, 28);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(57, 17);
			this.label2.TabIndex = 16;
			this.label2.Text = "fotograf";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(25, 29);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(34, 17);
			this.label1.TabIndex = 15;
			this.label1.Text = "fiyat";
			// 
			// barkodsuz_kaydet
			// 
			this.barkodsuz_kaydet.Location = new System.Drawing.Point(592, 546);
			this.barkodsuz_kaydet.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.barkodsuz_kaydet.Name = "barkodsuz_kaydet";
			this.barkodsuz_kaydet.Size = new System.Drawing.Size(80, 72);
			this.barkodsuz_kaydet.TabIndex = 11;
			this.barkodsuz_kaydet.Text = "kaydet";
			this.barkodsuz_kaydet.UseVisualStyleBackColor = true;
			this.barkodsuz_kaydet.Click += new System.EventHandler(this.barkodsuz_kaydet_Click);
			// 
			// button2
			// 
			this.button2.Location = new System.Drawing.Point(305, 546);
			this.button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(80, 72);
			this.button2.TabIndex = 10;
			this.button2.Text = "güncelle";
			this.button2.UseVisualStyleBackColor = true;
			// 
			// barkodsuz_urun_grubu_guncelle
			// 
			this.barkodsuz_urun_grubu_guncelle.Location = new System.Drawing.Point(27, 552);
			this.barkodsuz_urun_grubu_guncelle.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.barkodsuz_urun_grubu_guncelle.Name = "barkodsuz_urun_grubu_guncelle";
			this.barkodsuz_urun_grubu_guncelle.Size = new System.Drawing.Size(80, 72);
			this.barkodsuz_urun_grubu_guncelle.TabIndex = 9;
			this.barkodsuz_urun_grubu_guncelle.Text = "güncelle";
			this.barkodsuz_urun_grubu_guncelle.UseVisualStyleBackColor = true;
			this.barkodsuz_urun_grubu_guncelle.Click += new System.EventHandler(this.barkodsuz_urun_grubu_guncelle_Click);
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(306, 113);
			this.textBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(99, 22);
			this.textBox4.TabIndex = 3;
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(28, 117);
			this.textBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(99, 22);
			this.textBox3.TabIndex = 2;
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(465, 52);
			this.textBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(99, 22);
			this.textBox2.TabIndex = 1;
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(28, 55);
			this.textBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(99, 22);
			this.textBox1.TabIndex = 0;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.panel2);
			this.tabPage2.Controls.Add(this.groupBox4);
			this.tabPage2.Controls.Add(this.groupBox3);
			this.tabPage2.Location = new System.Drawing.Point(4, 104);
			this.tabPage2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tabPage2.Size = new System.Drawing.Size(1672, 888);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Kasiyer&Saat";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// panel2
			// 
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(1614, 73);
			this.panel2.TabIndex = 10;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.dateTimePicker12);
			this.groupBox4.Controls.Add(this.dateTimePicker11);
			this.groupBox4.Controls.Add(this.dateTimePicker10);
			this.groupBox4.Controls.Add(this.dateTimePicker9);
			this.groupBox4.Controls.Add(this.label31);
			this.groupBox4.Controls.Add(this.label30);
			this.groupBox4.Controls.Add(this.dateTimePicker8);
			this.groupBox4.Controls.Add(this.dateTimePicker7);
			this.groupBox4.Controls.Add(this.dateTimePicker6);
			this.groupBox4.Controls.Add(this.dateTimePicker5);
			this.groupBox4.Controls.Add(this.button6);
			this.groupBox4.Controls.Add(this.label18);
			this.groupBox4.Controls.Add(this.label17);
			this.groupBox4.Controls.Add(this.label16);
			this.groupBox4.Controls.Add(this.label15);
			this.groupBox4.Controls.Add(this.label14);
			this.groupBox4.Controls.Add(this.label13);
			this.groupBox4.Controls.Add(this.textBox13);
			this.groupBox4.Controls.Add(this.textBox12);
			this.groupBox4.Location = new System.Drawing.Point(915, 90);
			this.groupBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox4.Size = new System.Drawing.Size(699, 438);
			this.groupBox4.TabIndex = 9;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Saat Belirle";
			// 
			// dateTimePicker12
			// 
			this.dateTimePicker12.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker12.Location = new System.Drawing.Point(426, 218);
			this.dateTimePicker12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker12.Name = "dateTimePicker12";
			this.dateTimePicker12.ShowUpDown = true;
			this.dateTimePicker12.Size = new System.Drawing.Size(96, 22);
			this.dateTimePicker12.TabIndex = 22;
			// 
			// dateTimePicker11
			// 
			this.dateTimePicker11.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker11.Location = new System.Drawing.Point(317, 218);
			this.dateTimePicker11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker11.Name = "dateTimePicker11";
			this.dateTimePicker11.ShowUpDown = true;
			this.dateTimePicker11.Size = new System.Drawing.Size(96, 22);
			this.dateTimePicker11.TabIndex = 21;
			// 
			// dateTimePicker10
			// 
			this.dateTimePicker10.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker10.Location = new System.Drawing.Point(139, 218);
			this.dateTimePicker10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker10.Name = "dateTimePicker10";
			this.dateTimePicker10.ShowUpDown = true;
			this.dateTimePicker10.Size = new System.Drawing.Size(96, 22);
			this.dateTimePicker10.TabIndex = 20;
			// 
			// dateTimePicker9
			// 
			this.dateTimePicker9.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker9.Location = new System.Drawing.Point(26, 218);
			this.dateTimePicker9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker9.Name = "dateTimePicker9";
			this.dateTimePicker9.ShowUpDown = true;
			this.dateTimePicker9.Size = new System.Drawing.Size(96, 22);
			this.dateTimePicker9.TabIndex = 19;
			// 
			// label31
			// 
			this.label31.AutoSize = true;
			this.label31.Location = new System.Drawing.Point(431, 154);
			this.label31.Name = "label31";
			this.label31.Size = new System.Drawing.Size(50, 17);
			this.label31.TabIndex = 18;
			this.label31.Text = "Aksam";
			// 
			// label30
			// 
			this.label30.AutoSize = true;
			this.label30.Location = new System.Drawing.Point(313, 154);
			this.label30.Name = "label30";
			this.label30.Size = new System.Drawing.Size(49, 17);
			this.label30.TabIndex = 17;
			this.label30.Text = "Sabah";
			// 
			// dateTimePicker8
			// 
			this.dateTimePicker8.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker8.Location = new System.Drawing.Point(139, 182);
			this.dateTimePicker8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker8.Name = "dateTimePicker8";
			this.dateTimePicker8.ShowUpDown = true;
			this.dateTimePicker8.Size = new System.Drawing.Size(96, 22);
			this.dateTimePicker8.TabIndex = 16;
			// 
			// dateTimePicker7
			// 
			this.dateTimePicker7.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker7.Location = new System.Drawing.Point(426, 182);
			this.dateTimePicker7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker7.Name = "dateTimePicker7";
			this.dateTimePicker7.ShowUpDown = true;
			this.dateTimePicker7.Size = new System.Drawing.Size(96, 22);
			this.dateTimePicker7.TabIndex = 15;
			// 
			// dateTimePicker6
			// 
			this.dateTimePicker6.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker6.Location = new System.Drawing.Point(26, 182);
			this.dateTimePicker6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker6.Name = "dateTimePicker6";
			this.dateTimePicker6.ShowUpDown = true;
			this.dateTimePicker6.Size = new System.Drawing.Size(96, 22);
			this.dateTimePicker6.TabIndex = 14;
			// 
			// dateTimePicker5
			// 
			this.dateTimePicker5.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker5.Location = new System.Drawing.Point(316, 182);
			this.dateTimePicker5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker5.Name = "dateTimePicker5";
			this.dateTimePicker5.ShowUpDown = true;
			this.dateTimePicker5.Size = new System.Drawing.Size(96, 22);
			this.dateTimePicker5.TabIndex = 13;
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(564, 315);
			this.button6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(80, 72);
			this.button6.TabIndex = 12;
			this.button6.Text = "Kaydet";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// label18
			// 
			this.label18.AutoSize = true;
			this.label18.Location = new System.Drawing.Point(156, 154);
			this.label18.Name = "label18";
			this.label18.Size = new System.Drawing.Size(50, 17);
			this.label18.TabIndex = 11;
			this.label18.Text = "Aksam";
			// 
			// label17
			// 
			this.label17.AutoSize = true;
			this.label17.Location = new System.Drawing.Point(34, 154);
			this.label17.Name = "label17";
			this.label17.Size = new System.Drawing.Size(49, 17);
			this.label17.TabIndex = 10;
			this.label17.Text = "Sabah";
			// 
			// label16
			// 
			this.label16.AutoSize = true;
			this.label16.Location = new System.Drawing.Point(313, 74);
			this.label16.Name = "label16";
			this.label16.Size = new System.Drawing.Size(79, 17);
			this.label16.TabIndex = 9;
			this.label16.Text = "Hafta Sonu";
			// 
			// label15
			// 
			this.label15.AutoSize = true;
			this.label15.Location = new System.Drawing.Point(22, 81);
			this.label15.Name = "label15";
			this.label15.Size = new System.Drawing.Size(59, 17);
			this.label15.TabIndex = 8;
			this.label15.Text = "Hafta İçi";
			// 
			// label14
			// 
			this.label14.AutoSize = true;
			this.label14.Location = new System.Drawing.Point(302, 123);
			this.label14.Name = "label14";
			this.label14.Size = new System.Drawing.Size(135, 17);
			this.label14.TabIndex = 7;
			this.label14.Text = "Akşam Yemeği Fiyat";
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(19, 123);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(88, 17);
			this.label13.TabIndex = 6;
			this.label13.Text = "Kahvaltı fiyat";
			// 
			// textBox13
			// 
			this.textBox13.Location = new System.Drawing.Point(444, 118);
			this.textBox13.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox13.Name = "textBox13";
			this.textBox13.Size = new System.Drawing.Size(99, 22);
			this.textBox13.TabIndex = 1;
			// 
			// textBox12
			// 
			this.textBox12.Location = new System.Drawing.Point(136, 118);
			this.textBox12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox12.Name = "textBox12";
			this.textBox12.Size = new System.Drawing.Size(99, 22);
			this.textBox12.TabIndex = 0;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.dataGridView5);
			this.groupBox3.Controls.Add(this.label12);
			this.groupBox3.Controls.Add(this.comboBox1);
			this.groupBox3.Controls.Add(this.label11);
			this.groupBox3.Controls.Add(this.textBox10);
			this.groupBox3.Controls.Add(this.label10);
			this.groupBox3.Controls.Add(this.textBox11);
			this.groupBox3.Controls.Add(this.button3);
			this.groupBox3.Location = new System.Drawing.Point(92, 80);
			this.groupBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox3.Size = new System.Drawing.Size(743, 438);
			this.groupBox3.TabIndex = 8;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Kasiyer Ekle";
			// 
			// dataGridView5
			// 
			this.dataGridView5.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
			this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView5.Location = new System.Drawing.Point(267, 107);
			this.dataGridView5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dataGridView5.Name = "dataGridView5";
			this.dataGridView5.RowTemplate.Height = 28;
			this.dataGridView5.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
			this.dataGridView5.Size = new System.Drawing.Size(412, 138);
			this.dataGridView5.TabIndex = 4;
			// 
			// label12
			// 
			this.label12.AutoSize = true;
			this.label12.Location = new System.Drawing.Point(17, 228);
			this.label12.Name = "label12";
			this.label12.Size = new System.Drawing.Size(35, 17);
			this.label12.TabIndex = 7;
			this.label12.Text = "şifre";
			// 
			// comboBox1
			// 
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Items.AddRange(new object[] {
            "2",
            "1"});
			this.comboBox1.Location = new System.Drawing.Point(116, 114);
			this.comboBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(108, 24);
			this.comboBox1.TabIndex = 0;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(17, 173);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(77, 17);
			this.label11.TabIndex = 6;
			this.label11.Text = "kullanıcıadi";
			// 
			// textBox10
			// 
			this.textBox10.Location = new System.Drawing.Point(116, 168);
			this.textBox10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox10.Name = "textBox10";
			this.textBox10.Size = new System.Drawing.Size(108, 22);
			this.textBox10.TabIndex = 1;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(17, 120);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(37, 17);
			this.label10.TabIndex = 5;
			this.label10.Text = "yetki";
			// 
			// textBox11
			// 
			this.textBox11.Location = new System.Drawing.Point(116, 224);
			this.textBox11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.textBox11.Name = "textBox11";
			this.textBox11.Size = new System.Drawing.Size(108, 22);
			this.textBox11.TabIndex = 2;
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(599, 325);
			this.button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(80, 72);
			this.button3.TabIndex = 3;
			this.button3.Text = "kaydet";
			this.button3.UseVisualStyleBackColor = true;
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.chart1);
			this.tabPage3.Controls.Add(this.button1);
			this.tabPage3.Controls.Add(this.groupBox9);
			this.tabPage3.Controls.Add(this.groupBox8);
			this.tabPage3.Controls.Add(this.groupBox7);
			this.tabPage3.Controls.Add(this.groupBox6);
			this.tabPage3.Controls.Add(this.listBox1);
			this.tabPage3.Controls.Add(this.groupBox5);
			this.tabPage3.Location = new System.Drawing.Point(4, 104);
			this.tabPage3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.tabPage3.Size = new System.Drawing.Size(1672, 888);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Analiz";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// chart1
			// 
			chartArea1.Name = "ChartArea1";
			this.chart1.ChartAreas.Add(chartArea1);
			legend1.Name = "Legend1";
			this.chart1.Legends.Add(legend1);
			this.chart1.Location = new System.Drawing.Point(17, 210);
			this.chart1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.chart1.Name = "chart1";
			series1.ChartArea = "ChartArea1";
			series1.Legend = "Legend1";
			series1.Name = "yemek";
			series2.ChartArea = "ChartArea1";
			series2.Legend = "Legend1";
			series2.Name = "kahvaltilik";
			series3.ChartArea = "ChartArea1";
			series3.Legend = "Legend1";
			series3.Name = "icecek";
			series4.ChartArea = "ChartArea1";
			series4.Legend = "Legend1";
			series4.Name = "kahve";
			this.chart1.Series.Add(series1);
			this.chart1.Series.Add(series2);
			this.chart1.Series.Add(series3);
			this.chart1.Series.Add(series4);
			this.chart1.Size = new System.Drawing.Size(728, 574);
			this.chart1.TabIndex = 23;
			this.chart1.Text = "chart1";
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(1578, 43);
			this.button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(60, 61);
			this.button1.TabIndex = 22;
			this.button1.Text = "grafik";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// groupBox9
			// 
			this.groupBox9.Controls.Add(this.button12);
			this.groupBox9.Controls.Add(this.comboBox6);
			this.groupBox9.Controls.Add(this.comboBox7);
			this.groupBox9.Controls.Add(this.label27);
			this.groupBox9.Controls.Add(this.label28);
			this.groupBox9.Location = new System.Drawing.Point(864, 22);
			this.groupBox9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox9.Name = "groupBox9";
			this.groupBox9.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox9.Size = new System.Drawing.Size(338, 161);
			this.groupBox9.TabIndex = 21;
			this.groupBox9.TabStop = false;
			this.groupBox9.Text = "Urun Satış Analizi";
			// 
			// button12
			// 
			this.button12.Location = new System.Drawing.Point(22, 22);
			this.button12.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(67, 60);
			this.button12.TabIndex = 14;
			this.button12.Text = "Ara";
			this.button12.UseVisualStyleBackColor = true;
			// 
			// comboBox6
			// 
			this.comboBox6.FormattingEnabled = true;
			this.comboBox6.Location = new System.Drawing.Point(18, 111);
			this.comboBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.comboBox6.Name = "comboBox6";
			this.comboBox6.Size = new System.Drawing.Size(107, 24);
			this.comboBox6.TabIndex = 15;
			// 
			// comboBox7
			// 
			this.comboBox7.FormattingEnabled = true;
			this.comboBox7.Location = new System.Drawing.Point(145, 111);
			this.comboBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.comboBox7.Name = "comboBox7";
			this.comboBox7.Size = new System.Drawing.Size(107, 24);
			this.comboBox7.TabIndex = 16;
			// 
			// label27
			// 
			this.label27.AutoSize = true;
			this.label27.Location = new System.Drawing.Point(15, 85);
			this.label27.Name = "label27";
			this.label27.Size = new System.Drawing.Size(89, 17);
			this.label27.TabIndex = 17;
			this.label27.Text = "urun grupları";
			// 
			// label28
			// 
			this.label28.AutoSize = true;
			this.label28.Location = new System.Drawing.Point(142, 85);
			this.label28.Name = "label28";
			this.label28.Size = new System.Drawing.Size(60, 17);
			this.label28.TabIndex = 18;
			this.label28.Text = "urun adi";
			// 
			// groupBox8
			// 
			this.groupBox8.Controls.Add(this.button11);
			this.groupBox8.Controls.Add(this.comboBox4);
			this.groupBox8.Controls.Add(this.comboBox5);
			this.groupBox8.Controls.Add(this.label25);
			this.groupBox8.Controls.Add(this.label26);
			this.groupBox8.Location = new System.Drawing.Point(521, 22);
			this.groupBox8.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox8.Name = "groupBox8";
			this.groupBox8.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox8.Size = new System.Drawing.Size(338, 161);
			this.groupBox8.TabIndex = 21;
			this.groupBox8.TabStop = false;
			this.groupBox8.Text = "Toplam satış";
			// 
			// button11
			// 
			this.button11.Location = new System.Drawing.Point(27, 22);
			this.button11.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button11.Name = "button11";
			this.button11.Size = new System.Drawing.Size(67, 60);
			this.button11.TabIndex = 8;
			this.button11.Text = "Ara";
			this.button11.UseVisualStyleBackColor = true;
			// 
			// comboBox4
			// 
			this.comboBox4.FormattingEnabled = true;
			this.comboBox4.Items.AddRange(new object[] {
            "Hepsi",
            "Parmak İzi",
            "Nakit"});
			this.comboBox4.Location = new System.Drawing.Point(11, 111);
			this.comboBox4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.comboBox4.Name = "comboBox4";
			this.comboBox4.Size = new System.Drawing.Size(107, 24);
			this.comboBox4.TabIndex = 10;
			// 
			// comboBox5
			// 
			this.comboBox5.FormattingEnabled = true;
			this.comboBox5.Items.AddRange(new object[] {
            "Hepsi",
            "Sabah",
            "Akşam",
            "Toplam"});
			this.comboBox5.Location = new System.Drawing.Point(133, 111);
			this.comboBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.comboBox5.Name = "comboBox5";
			this.comboBox5.Size = new System.Drawing.Size(107, 24);
			this.comboBox5.TabIndex = 11;
			// 
			// label25
			// 
			this.label25.AutoSize = true;
			this.label25.Location = new System.Drawing.Point(10, 93);
			this.label25.Name = "label25";
			this.label25.Size = new System.Drawing.Size(110, 17);
			this.label25.TabIndex = 12;
			this.label25.Text = "nakit & parmak izi";
			// 
			// label26
			// 
			this.label26.AutoSize = true;
			this.label26.Location = new System.Drawing.Point(139, 93);
			this.label26.Name = "label26";
			this.label26.Size = new System.Drawing.Size(37, 17);
			this.label26.TabIndex = 13;
			this.label26.Text = "vakit";
			// 
			// groupBox7
			// 
			this.groupBox7.Controls.Add(this.button10);
			this.groupBox7.Controls.Add(this.comboBox3);
			this.groupBox7.Location = new System.Drawing.Point(271, 22);
			this.groupBox7.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox7.Name = "groupBox7";
			this.groupBox7.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox7.Size = new System.Drawing.Size(244, 161);
			this.groupBox7.TabIndex = 20;
			this.groupBox7.TabStop = false;
			this.groupBox7.Text = "Nakit Analizi";
			// 
			// button10
			// 
			this.button10.Location = new System.Drawing.Point(16, 22);
			this.button10.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(67, 60);
			this.button10.TabIndex = 5;
			this.button10.Text = "Ara";
			this.button10.UseVisualStyleBackColor = true;
			// 
			// comboBox3
			// 
			this.comboBox3.FormattingEnabled = true;
			this.comboBox3.Location = new System.Drawing.Point(16, 111);
			this.comboBox3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.comboBox3.Name = "comboBox3";
			this.comboBox3.Size = new System.Drawing.Size(107, 24);
			this.comboBox3.TabIndex = 7;
			// 
			// groupBox6
			// 
			this.groupBox6.Controls.Add(this.button9);
			this.groupBox6.Controls.Add(this.comboBox2);
			this.groupBox6.Location = new System.Drawing.Point(17, 22);
			this.groupBox6.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox6.Name = "groupBox6";
			this.groupBox6.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox6.Size = new System.Drawing.Size(244, 161);
			this.groupBox6.TabIndex = 19;
			this.groupBox6.TabStop = false;
			this.groupBox6.Text = "kasiyer satış raporu";
			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(22, 22);
			this.button9.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(67, 60);
			this.button9.TabIndex = 2;
			this.button9.Text = "Ara";
			this.button9.UseVisualStyleBackColor = true;
			// 
			// comboBox2
			// 
			this.comboBox2.FormattingEnabled = true;
			this.comboBox2.Location = new System.Drawing.Point(22, 111);
			this.comboBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.comboBox2.Name = "comboBox2";
			this.comboBox2.Size = new System.Drawing.Size(107, 24);
			this.comboBox2.TabIndex = 3;
//			this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
			// 
			// listBox1
			// 
			this.listBox1.FormattingEnabled = true;
			this.listBox1.ItemHeight = 16;
			this.listBox1.Location = new System.Drawing.Point(769, 194);
			this.listBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.listBox1.Name = "listBox1";
			this.listBox1.Size = new System.Drawing.Size(879, 612);
			this.listBox1.TabIndex = 1;
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.dateTimePicker4);
			this.groupBox5.Controls.Add(this.dateTimePicker3);
			this.groupBox5.Controls.Add(this.label21);
			this.groupBox5.Controls.Add(this.label20);
			this.groupBox5.Controls.Add(this.dateTimePicker2);
			this.groupBox5.Controls.Add(this.dateTimePicker1);
			this.groupBox5.Location = new System.Drawing.Point(1207, 22);
			this.groupBox5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Padding = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.groupBox5.Size = new System.Drawing.Size(338, 161);
			this.groupBox5.TabIndex = 0;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Tarih";
			// 
			// dateTimePicker4
			// 
			this.dateTimePicker4.Location = new System.Drawing.Point(133, 113);
			this.dateTimePicker4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker4.Name = "dateTimePicker4";
			this.dateTimePicker4.Size = new System.Drawing.Size(178, 22);
			this.dateTimePicker4.TabIndex = 8;
			// 
			// dateTimePicker3
			// 
			this.dateTimePicker3.Location = new System.Drawing.Point(133, 84);
			this.dateTimePicker3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker3.Name = "dateTimePicker3";
			this.dateTimePicker3.Size = new System.Drawing.Size(178, 22);
			this.dateTimePicker3.TabIndex = 7;
			// 
			// label21
			// 
			this.label21.AutoSize = true;
			this.label21.Location = new System.Drawing.Point(24, 40);
			this.label21.Name = "label21";
			this.label21.Size = new System.Drawing.Size(57, 17);
			this.label21.TabIndex = 6;
			this.label21.Text = "Bugün :";
			// 
			// label20
			// 
			this.label20.AutoSize = true;
			this.label20.Location = new System.Drawing.Point(86, 40);
			this.label20.Name = "label20";
			this.label20.Size = new System.Drawing.Size(54, 17);
			this.label20.TabIndex = 5;
			this.label20.Text = "label20";
			// 
			// dateTimePicker2
			// 
			this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker2.Location = new System.Drawing.Point(27, 113);
			this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker2.Name = "dateTimePicker2";
			this.dateTimePicker2.ShowUpDown = true;
			this.dateTimePicker2.Size = new System.Drawing.Size(92, 22);
			this.dateTimePicker2.TabIndex = 1;
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Time;
			this.dateTimePicker1.Location = new System.Drawing.Point(27, 84);
			this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.ShowUpDown = true;
			this.dateTimePicker1.Size = new System.Drawing.Size(92, 22);
			this.dateTimePicker1.TabIndex = 0;
			// 
			// openFileDialog1
			// 
			this.openFileDialog1.FileName = "openFileDialog1";
			// 
			// openFileDialog2
			// 
			this.openFileDialog2.FileName = "openFileDialog2";
			// 
			// denemeDataSet1
			// 
			this.denemeDataSet1.DataSetName = "denemeDataSet1";
			this.denemeDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// denemeDataSet1BindingSource
			// 
			this.denemeDataSet1BindingSource.DataSource = this.denemeDataSet1;
			this.denemeDataSet1BindingSource.Position = 0;
			// 
			// Home
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1682, 950);
			this.Controls.Add(this.tabControl1);
			this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
			this.MaximizeBox = false;
			this.Name = "Home";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Home";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.Home_Load);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.tabPage2.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox3.ResumeLayout(false);
			this.groupBox3.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
			this.tabPage3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
			this.groupBox9.ResumeLayout(false);
			this.groupBox9.PerformLayout();
			this.groupBox8.ResumeLayout(false);
			this.groupBox8.PerformLayout();
			this.groupBox7.ResumeLayout(false);
			this.groupBox6.ResumeLayout(false);
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.denemeDataSet1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.denemeDataSet1BindingSource)).EndInit();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.TabPage tabPage2;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.PictureBox pictureBox2;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button barkodlu_kaydet;
		private System.Windows.Forms.TextBox textBox9;
		private System.Windows.Forms.TextBox textBox8;
		private System.Windows.Forms.TextBox textBox7;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button barkodsuz_kaydet;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Button barkodsuz_urun_grubu_guncelle;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.Label label18;
		private System.Windows.Forms.Label label17;
		private System.Windows.Forms.Label label16;
		private System.Windows.Forms.Label label15;
		private System.Windows.Forms.Label label14;
		private System.Windows.Forms.Label label13;
		private System.Windows.Forms.TextBox textBox13;
		private System.Windows.Forms.TextBox textBox12;
		private System.Windows.Forms.GroupBox groupBox3;
		private System.Windows.Forms.DataGridView dataGridView5;
		private System.Windows.Forms.Label label12;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Label label11;
		private System.Windows.Forms.TextBox textBox10;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.TextBox textBox11;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.OpenFileDialog openFileDialog2;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private System.Windows.Forms.DateTimePicker dateTimePicker2;
		private System.Windows.Forms.Label label20;
		private System.Windows.Forms.Label label21;
		private System.Windows.Forms.Label label28;
		private System.Windows.Forms.Label label27;
		private System.Windows.Forms.ComboBox comboBox7;
		private System.Windows.Forms.ComboBox comboBox6;
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Label label26;
		private System.Windows.Forms.Label label25;
		private System.Windows.Forms.ComboBox comboBox5;
		private System.Windows.Forms.ComboBox comboBox4;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.ComboBox comboBox3;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.ComboBox comboBox2;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.ListBox listBox1;
		private System.Windows.Forms.GroupBox groupBox9;
		private System.Windows.Forms.GroupBox groupBox8;
		private System.Windows.Forms.GroupBox groupBox7;
		private System.Windows.Forms.GroupBox groupBox6;
		private System.Windows.Forms.DateTimePicker dateTimePicker4;
		private System.Windows.Forms.DateTimePicker dateTimePicker3;
		private System.Windows.Forms.DateTimePicker dateTimePicker8;
		private System.Windows.Forms.DateTimePicker dateTimePicker7;
		private System.Windows.Forms.DateTimePicker dateTimePicker5;
		private System.Windows.Forms.Label label31;
		private System.Windows.Forms.Label label30;
		private System.Windows.Forms.TextBox textBox14;
		private System.Windows.Forms.ListBox listBox2;
		private System.Windows.Forms.BindingSource denemeDataSet1BindingSource;
		private denemeDataSet1 denemeDataSet1;
		private System.Windows.Forms.ListBox listBox5;
		private System.Windows.Forms.ListBox listBox4;
		private System.Windows.Forms.ListBox listBox3;
		private System.Windows.Forms.DateTimePicker dateTimePicker12;
		private System.Windows.Forms.DateTimePicker dateTimePicker11;
		private System.Windows.Forms.DateTimePicker dateTimePicker10;
		private System.Windows.Forms.DateTimePicker dateTimePicker9;
		public System.Windows.Forms.DateTimePicker dateTimePicker6;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.DataVisualization.Charting.Chart chart1;
	}
}