Order System.
You can use cafe, pub, restaurant or dormitory canteen.
Setup : Not yet created. Just file name

Version : -Beta
